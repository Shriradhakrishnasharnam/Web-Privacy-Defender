# WebPrivacyDefender - Disable WebRTC for Firefox

## Overview
**WebPrivacyDefender** is a lightweight addon designed to enhance your online privacy by disabling WebRTC (Web Real-Time Communication). WebRTC can leak your actual IP address while using a VPN, compromising your privacy. This addon fixes that issue, making your VPN more effective.

## Features
- **Disable WebRTC**: Prevents WebRTC from revealing your real IP address.
- **Easy Toggle**: Quickly enable or disable WebRTC by clicking the addon’s icon in your browser toolbar.

## Why Use WebPrivacyDefender?
WebRTC is a powerful communication protocol that can be exploited to expose your IP address, even when using a VPN. By default, WebRTC may not be adequately secured, leading to potential privacy risks. **WebPrivacyDefender** helps mitigate these risks, ensuring that your VPN remains effective and your online activities stay private.

## Installation
1. Download the addon from the Firefox Add-ons (https://addons.mozilla.org) 
2. Click the "Add to Firefox" button to install.

## Usage
- After installation, click the **WebPrivacyDefender** icon in the toolbar to toggle WebRTC on or off.
- The addon will indicate whether WebRTC is currently enabled or disabled.

## Support
For any issues or feature requests, please open an issue in the github repository. (github.com/shriradhakrishnasharnam)

## License
This project is licensed under the [Mozilla Public License 2.0 (MPL 2)](https://www.mozilla.org/en-US/MPL/2.0/).

---

Stay private, stay secure with **WebPrivacyDefender**!